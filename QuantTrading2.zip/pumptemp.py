﻿#coding:utf-8
import xml.etree.cElementTree as ET
import sys

out_file = open('./test/TestBackTest/Config/Config.cpp', 'w+', encoding='UTF-8-SIG', newline='\n')

curr_node = ET.Element("root")
curr_node.append(ET.parse("./Model/Configs/TestBackTest.xml").getroot())
parent_map = {}
pumpid = 0
parentpumpid = 0
target = 'target'
def get_attr(node, name):
    while node != None:
        if node.get(name) == None:
            if node in parent_map:
                node = parent_map[node]
            else:
                break
        else:
            return node.get(name)
    return ""

out_file.write("#pragma warning(disable: 4311)\n")
out_file.write("")
entry_name = "config"
parent1 = curr_node
curr_node = curr_node.find(entry_name)
parent_map[curr_node] = parent1

out_file.write("#include \"Config.h\"\n")
out_file.write("#include <Spark/Serialization/json/json.h>\n")
out_file.write("#include <iostream>\n")
out_file.write("#include <fstream>\n")
out_file.write("#include <stdexcept>\n")
out_file.write("\n")
out_file.write("using namespace std;\n")
out_file.write("\n")
out_file.write("")
formatSymbols = {}
formatSymbols["bool"] = "d"
formatSymbols["char"] = "c"
formatSymbols["int"] = "d"
formatSymbols["double"] = "f"
formatSymbols["string"] = "s"
out_file.write("\n")
out_file.write("Config Config::m_Instance;\n")
out_file.write("Config::Config()\n")
out_file.write("{\n")
out_file.write("\n")
out_file.write("}\n")
out_file.write("Config& Config::GetInstance()\n")
out_file.write("{\n")
out_file.write("	return m_Instance;\n")
out_file.write("}\n")
out_file.write("void Config::Load(const char* fileName)\n")
out_file.write("{\n")
out_file.write("	Json::Reader reader;\n")
out_file.write("	Json::Value root;\n")
out_file.write("	std::ifstream inFile(fileName, std::ios::binary);\n")
out_file.write("	if (!reader.parse(inFile, root))\n")
out_file.write("	{\n")
out_file.write("		std::string errorMsg = std::string(\"Parse Config Failed. FileName:\") + fileName;\n")
out_file.write("		std::cout << errorMsg << std::endl;\n")
out_file.write("		throw std::logic_error(errorMsg);\n")
out_file.write("	}\n")
out_file.write("	else\n")
out_file.write("	{\n")
out_file.write("		std::cout << \"Parse Config Success.\" << std::endl;\n")
out_file.write("	}\n")
out_file.write("	inFile.close();\n")
out_file.write("	\n")
out_file.write("")
entry_name = "items"
parent2 = curr_node
curr_node = curr_node.find(entry_name)
parent_map[curr_node] = parent2

parentpumpid = pumpid
pumpid = -1
parent3 = curr_node
for node3 in curr_node:
    curr_node = node3
    parent_map[curr_node] = parent3
    pumpid += 1
    if  get_attr(curr_node, "type") == "bool":
        out_file.write("	")
        out_file.write("%s" % get_attr(curr_node, "name"))
        out_file.write(" = root[\"")
        out_file.write("%s" % get_attr(curr_node, "name"))
        out_file.write("\"].asBool();\n")
        out_file.write("")
    elif  get_attr(curr_node, "type") == "char":
        out_file.write("	")
        out_file.write("%s" % get_attr(curr_node, "name"))
        out_file.write(" = root[\"")
        out_file.write("%s" % get_attr(curr_node, "name"))
        out_file.write("\"].asString()[0];\n")
        out_file.write("")
    elif  get_attr(curr_node, "type") == "int":
        out_file.write("	")
        out_file.write("%s" % get_attr(curr_node, "name"))
        out_file.write(" = root[\"")
        out_file.write("%s" % get_attr(curr_node, "name"))
        out_file.write("\"].asInt();\n")
        out_file.write("")
    elif  get_attr(curr_node, "type") == "double":
        out_file.write("	")
        out_file.write("%s" % get_attr(curr_node, "name"))
        out_file.write(" = root[\"")
        out_file.write("%s" % get_attr(curr_node, "name"))
        out_file.write("\"].asDouble();\n")
        out_file.write("")
    elif  get_attr(curr_node, "type") == "string":
        out_file.write("	")
        out_file.write("%s" % get_attr(curr_node, "name"))
        out_file.write(" = root[\"")
        out_file.write("%s" % get_attr(curr_node, "name"))
        out_file.write("\"].asString();\n")
        out_file.write("")
    elif  get_attr(curr_node, "type") == "list":
        out_file.write("	for (auto& subValue : root[\"")
        out_file.write("%s" % get_attr(curr_node, "name"))
        out_file.write("\"])\n")
        out_file.write("	{\n")
        out_file.write("")
        if  get_attr(curr_node, "modeltype") == "bool":
            out_file.write("		")
            out_file.write("%s" % get_attr(curr_node, "name"))
            out_file.write(".push_back(subValue.asBool());\n")
            out_file.write("")
        elif  get_attr(curr_node, "modeltype") == "int":
            out_file.write("		")
            out_file.write("%s" % get_attr(curr_node, "name"))
            out_file.write(".push_back(subValue.asInt());\n")
            out_file.write("")
        elif  get_attr(curr_node, "modeltype") == "double":
            out_file.write("		")
            out_file.write("%s" % get_attr(curr_node, "name"))
            out_file.write(".push_back(subValue.asDouble());\n")
            out_file.write("")
        elif  get_attr(curr_node, "modeltype") == "string":
            out_file.write("		")
            out_file.write("%s" % get_attr(curr_node, "name"))
            out_file.write(".push_back(subValue.asString());\n")
            out_file.write("")
        else:
            out_file.write("		")
            out_file.write("%s" % get_attr(curr_node, "modeltype"))
            out_file.write("* subRecord = new ")
            out_file.write("%s" % get_attr(curr_node, "modeltype"))
            out_file.write("();\n")
            out_file.write("")
            parentpumpid = pumpid
            pumpid = -1
            parent6 = curr_node
            for node6 in curr_node:
                curr_node = node6
                parent_map[curr_node] = parent6
                pumpid += 1
                if  get_attr(curr_node, "type") == "bool":
                    out_file.write("		subRecord->")
                    out_file.write("%s" % get_attr(curr_node, "name"))
                    out_file.write(" = subValue[\"")
                    out_file.write("%s" % get_attr(curr_node, "name"))
                    out_file.write("\"].asBool();\n")
                    out_file.write("")
                elif  get_attr(curr_node, "type") == "int":
                    out_file.write("		subRecord->")
                    out_file.write("%s" % get_attr(curr_node, "name"))
                    out_file.write(" = subValue[\"")
                    out_file.write("%s" % get_attr(curr_node, "name"))
                    out_file.write("\"].asInt();\n")
                    out_file.write("")
                elif  get_attr(curr_node, "type") == "double":
                    out_file.write("		subRecord->")
                    out_file.write("%s" % get_attr(curr_node, "name"))
                    out_file.write(" = subValue[\"")
                    out_file.write("%s" % get_attr(curr_node, "name"))
                    out_file.write("\"].asDouble();\n")
                    out_file.write("")
                elif  get_attr(curr_node, "type") == "string":
                    out_file.write("		subRecord->")
                    out_file.write("%s" % get_attr(curr_node, "name"))
                    out_file.write(" = subValue[\"")
                    out_file.write("%s" % get_attr(curr_node, "name"))
                    out_file.write("\"].asString();\n")
                    out_file.write("")
                elif  get_attr(curr_node, "type") == "list":
                    out_file.write("		auto& subSubValues = subValue[\"")
                    out_file.write("%s" % get_attr(curr_node, "name"))
                    out_file.write("\"];\n")
                    out_file.write("		for (auto& subSubValue : subSubValues)\n")
                    out_file.write("		{\n")
                    out_file.write("")
                    if  get_attr(curr_node, "modeltype") == "bool":
                        out_file.write("			subRecord->")
                        out_file.write("%s" % get_attr(curr_node, "name"))
                        out_file.write(".push_back(subSubValue.asBool());\n")
                        out_file.write("")
                    elif  get_attr(curr_node, "modeltype") == "int":
                        out_file.write("			subRecord->")
                        out_file.write("%s" % get_attr(curr_node, "name"))
                        out_file.write(".push_back(subSubValue.asInt());\n")
                        out_file.write("")
                    elif  get_attr(curr_node, "modeltype") == "double":
                        out_file.write("			subRecord->")
                        out_file.write("%s" % get_attr(curr_node, "name"))
                        out_file.write(".push_back(subSubValue.asDouble());\n")
                        out_file.write("")
                    elif  get_attr(curr_node, "modeltype") == "string":
                        out_file.write("			subRecord->")
                        out_file.write("%s" % get_attr(curr_node, "name"))
                        out_file.write(".push_back(subSubValue.asString());\n")
                        out_file.write("")
                    else:
                        out_file.write("			")
                        out_file.write("%s" % get_attr(curr_node, "modeltype"))
                        out_file.write("* subSubRecord = new ")
                        out_file.write("%s" % get_attr(curr_node, "modeltype"))
                        out_file.write("();\n")
                        out_file.write("")
                        parentpumpid = pumpid
                        pumpid = -1
                        parent9 = curr_node
                        for node9 in curr_node:
                            curr_node = node9
                            parent_map[curr_node] = parent9
                            pumpid += 1
                            if  get_attr(curr_node, "type") == "bool":
                                out_file.write("			subSubRecord->")
                                out_file.write("%s" % get_attr(curr_node, "name"))
                                out_file.write(" = subSubValue[\"")
                                out_file.write("%s" % get_attr(curr_node, "name"))
                                out_file.write("\"].asBool();\n")
                                out_file.write("")
                            elif  get_attr(curr_node, "type") == "int":
                                out_file.write("			subSubRecord->")
                                out_file.write("%s" % get_attr(curr_node, "name"))
                                out_file.write(" = subSubValue[\"")
                                out_file.write("%s" % get_attr(curr_node, "name"))
                                out_file.write("\"].asInt();\n")
                                out_file.write("")
                            elif  get_attr(curr_node, "type") == "double":
                                out_file.write("			subSubRecord->")
                                out_file.write("%s" % get_attr(curr_node, "name"))
                                out_file.write(" = subSubValue[\"")
                                out_file.write("%s" % get_attr(curr_node, "name"))
                                out_file.write("\"].asDouble();\n")
                                out_file.write("")
                            elif  get_attr(curr_node, "type") == "string":
                                out_file.write("			subSubRecord->")
                                out_file.write("%s" % get_attr(curr_node, "name"))
                                out_file.write(" = subSubValue[\"")
                                out_file.write("%s" % get_attr(curr_node, "name"))
                                out_file.write("\"].asString();\n")
                                out_file.write("")
                            
                        pumpid = parentpumpid
                        if curr_node != parent9:
                            curr_node = parent_map[curr_node]
                        out_file.write("			subRecord->")
                        out_file.write("%s" % get_attr(curr_node, "name"))
                        out_file.write(".push_back(subSubRecord);\n")
                        out_file.write("")
                    out_file.write("		}\n")
                    out_file.write("")
                
            pumpid = parentpumpid
            if curr_node != parent6:
                curr_node = parent_map[curr_node]
            out_file.write("		")
            out_file.write("%s" % get_attr(curr_node, "name"))
            out_file.write(".push_back(subRecord);\n")
            out_file.write("")
        out_file.write("	}\n")
        out_file.write("")
    
pumpid = parentpumpid
if curr_node != parent3:
    curr_node = parent_map[curr_node]

curr_node = parent_map[curr_node]
out_file.write("	Print();\n")
out_file.write("}\n")
out_file.write("\n")
out_file.write("\n")
out_file.write("\n")
out_file.write("void Config::Print()\n")
out_file.write("{\n")
out_file.write("")
entry_name = "items"
parent2 = curr_node
curr_node = curr_node.find(entry_name)
parent_map[curr_node] = parent2

parentpumpid = pumpid
pumpid = -1
parent3 = curr_node
for node3 in curr_node:
    curr_node = node3
    parent_map[curr_node] = parent3
    pumpid += 1
    if  get_attr(curr_node, "type") != "list":
        itemType=formatSymbols[ get_attr(curr_node, "type")]
        out_file.write("	printf(\"")
        out_file.write("%s" % get_attr(curr_node, "name"))
        out_file.write(":%")
        out_file.write("%s" % str(itemType))
        out_file.write("\\n\", ")
        out_file.write("%s" % get_attr(curr_node, "name"))
        if  get_attr(curr_node, "type") == "string":
            out_file.write(".c_str()")
        out_file.write(");\n")
        out_file.write("")
    
pumpid = parentpumpid
if curr_node != parent3:
    curr_node = parent_map[curr_node]
parentpumpid = pumpid
pumpid = -1
parent3 = curr_node
for node3 in curr_node:
    curr_node = node3
    parent_map[curr_node] = parent3
    pumpid += 1
    if  get_attr(curr_node, "type") == "list":
        if  get_attr(curr_node, "modeltype") in str(formatSymbols):
            out_file.write("	printf(\"")
            out_file.write("%s" % get_attr(curr_node, "name"))
            out_file.write(":[\");\n")
            out_file.write("	for (auto& record : ")
            out_file.write("%s" % get_attr(curr_node, "name"))
            out_file.write(")\n")
            out_file.write("	{\n")
            out_file.write("		printf(\"")
            itemType=formatSymbols[ get_attr(curr_node, "modeltype")]
            out_file.write("%")
            out_file.write("%s" % str(itemType))
            out_file.write(", \", record")
            if  get_attr(curr_node, "modeltype") == "string":
                out_file.write(".c_str()")
            out_file.write(");\n")
            out_file.write("	}\n")
            out_file.write("	printf(\"]\\n\");\n")
            out_file.write("")
        else:
            out_file.write("	printf(\"")
            out_file.write("%s" % get_attr(curr_node, "name"))
            out_file.write(":[\\n\");\n")
            out_file.write("	for (auto record : ")
            out_file.write("%s" % get_attr(curr_node, "name"))
            out_file.write(")\n")
            out_file.write("	{\n")
            out_file.write("		printf(\"{\\n\");\n")
            out_file.write("		printf(\"\\t")
            parentpumpid = pumpid
            pumpid = -1
            parent6 = curr_node
            for node6 in curr_node:
                curr_node = node6
                parent_map[curr_node] = parent6
                pumpid += 1
                if  get_attr(curr_node, "type") != "list":
                    itemType=formatSymbols[ get_attr(curr_node, "type")]
                    out_file.write("%s" % get_attr(curr_node, "name"))
                    out_file.write(":%")
                    out_file.write("%s" % str(itemType))
                    out_file.write(", ")
                
            pumpid = parentpumpid
            if curr_node != parent6:
                curr_node = parent_map[curr_node]
            out_file.write("\\n\",\n")
            out_file.write("			")
            parentpumpid = pumpid
            pumpid = -1
            parent6 = curr_node
            for node6 in curr_node:
                curr_node = node6
                parent_map[curr_node] = parent6
                pumpid += 1
                if  get_attr(curr_node, "type") != "list":
                    if pumpid > 0:
                        out_file.write(", ")
                    out_file.write("record->")
                    out_file.write("%s" % get_attr(curr_node, "name"))
                    if  get_attr(curr_node, "type") == "string":
                        out_file.write(".c_str()")
                
            pumpid = parentpumpid
            if curr_node != parent6:
                curr_node = parent_map[curr_node]
            out_file.write(");\n")
            out_file.write("")
            parentpumpid = pumpid
            pumpid = -1
            parent6 = curr_node
            for node6 in curr_node:
                curr_node = node6
                parent_map[curr_node] = parent6
                pumpid += 1
                if  get_attr(curr_node, "type") == "list":
                    if  get_attr(curr_node, "modeltype") in str(formatSymbols):
                        out_file.write("		printf(\"\\t")
                        out_file.write("%s" % get_attr(curr_node, "name"))
                        out_file.write(":[\");\n")
                        out_file.write("		for (auto& subRecord : record->")
                        out_file.write("%s" % get_attr(curr_node, "name"))
                        out_file.write(")\n")
                        out_file.write("		{\n")
                        out_file.write("			printf(\"")
                        itemType=formatSymbols[ get_attr(curr_node, "modeltype")]
                        out_file.write("%")
                        out_file.write("%s" % str(itemType))
                        out_file.write(", \", subRecord")
                        if  get_attr(curr_node, "modeltype") == "string":
                            out_file.write(".c_str()")
                        out_file.write(");\n")
                        out_file.write("		}\n")
                        out_file.write("		printf(\"]\\n\");\n")
                        out_file.write("")
                    else:
                        out_file.write("		printf(\"\\t")
                        out_file.write("%s" % get_attr(curr_node, "name"))
                        out_file.write(":[\\n\");\n")
                        out_file.write("		for (auto& subRecord : record->")
                        out_file.write("%s" % get_attr(curr_node, "name"))
                        out_file.write(")\n")
                        out_file.write("		{\n")
                        out_file.write("			printf(\"\\t\\t{")
                        parentpumpid = pumpid
                        pumpid = -1
                        parent9 = curr_node
                        for node9 in curr_node:
                            curr_node = node9
                            parent_map[curr_node] = parent9
                            pumpid += 1
                            if  get_attr(curr_node, "type") != "list":
                                itemType=formatSymbols[ get_attr(curr_node, "type")]
                                out_file.write("%s" % get_attr(curr_node, "name"))
                                out_file.write(":%")
                                out_file.write("%s" % str(itemType))
                                out_file.write(", ")
                            
                        pumpid = parentpumpid
                        if curr_node != parent9:
                            curr_node = parent_map[curr_node]
                        out_file.write("},\\n\",\n")
                        out_file.write("				")
                        parentpumpid = pumpid
                        pumpid = -1
                        parent9 = curr_node
                        for node9 in curr_node:
                            curr_node = node9
                            parent_map[curr_node] = parent9
                            pumpid += 1
                            if  get_attr(curr_node, "type") != "list":
                                if pumpid > 0:
                                    out_file.write(", ")
                                out_file.write("subRecord->")
                                out_file.write("%s" % get_attr(curr_node, "name"))
                                if  get_attr(curr_node, "type") == "string":
                                    out_file.write(".c_str()")
                            
                        pumpid = parentpumpid
                        if curr_node != parent9:
                            curr_node = parent_map[curr_node]
                        out_file.write(");\n")
                        out_file.write("		}\n")
                        out_file.write("		printf(\"\\t]\\n\");\n")
                        out_file.write("")
                
            pumpid = parentpumpid
            if curr_node != parent6:
                curr_node = parent_map[curr_node]
            out_file.write("		printf(\"},\\n\");\n")
            out_file.write("	}\n")
            out_file.write("	printf(\"]\\n\");\n")
            out_file.write("")
    
pumpid = parentpumpid
if curr_node != parent3:
    curr_node = parent_map[curr_node]

curr_node = parent_map[curr_node]
out_file.write("}\n")
out_file.write("\n")
out_file.write("")

curr_node = parent_map[curr_node]
out_file.close()
