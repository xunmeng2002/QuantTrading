
macro(restore_vcpkg_root)
    if(WIN32)
        execute_process(
            COMMAND powershell -NoProfile -Command "$v = [Environment]::GetEnvironmentVariable('VCPKG_ROOT', 'User'); if (-not $v) { $v = [Environment]::GetEnvironmentVariable('VCPKG_ROOT', 'Machine'); }; Write-Output $v"
			OUTPUT_VARIABLE
				_ORIG_VCPKG_ROOT
				OUTPUT_STRIP_TRAILING_WHITESPACE)
        if(_ORIG_VCPKG_ROOT)
            set(ENV{VCPKG_ROOT} "${_ORIG_VCPKG_ROOT}")
            message(STATUS "VCPKG_ROOT restored from system env: ${_ORIG_VCPKG_ROOT}")
        else()
            message(WARNING "VCPKG_ROOT hijacked by VS but could not read from registry!")
        endif()
    endif()
endmacro()

macro(reuse_git_proxy_for_vcpkg)
    # vcpkg 的下载器只读 HTTP_PROXY/HTTPS_PROXY 环境变量，不读 git config；
    # 用户若已在 git 中配置过 http(s) 代理，此处复用它，避免 vcpkg 直连 GitHub 超时。
    if(NOT DEFINED ENV{HTTP_PROXY} AND NOT DEFINED ENV{HTTPS_PROXY})
        execute_process(
            COMMAND git config --get-regexp "proxy$"
            OUTPUT_VARIABLE _git_proxy_output
            OUTPUT_STRIP_TRAILING_WHITESPACE
            ERROR_QUIET)
        if(_git_proxy_output)
            # --get-regexp 输出为 "key value"（空格分隔），取末行第一个空格后的内容
            string(REPLACE "\n" ";" _git_proxy_lines "${_git_proxy_output}")
            list(GET _git_proxy_lines -1 _git_proxy_last_line)
            string(REGEX MATCH "^[^ ]+ (.+)$" _git_proxy_match "${_git_proxy_last_line}")
            if(CMAKE_MATCH_1)
                set(ENV{HTTP_PROXY}  "${CMAKE_MATCH_1}")
                set(ENV{HTTPS_PROXY} "${CMAKE_MATCH_1}")
                message(STATUS "vcpkg download proxy (reused from git config): ${CMAKE_MATCH_1}")
            endif()
        endif()
    endif()
endmacro()

macro(add_template_library name include_dir)
    add_library(${name} INTERFACE)
    target_include_directories(${name}
        INTERFACE
            $<BUILD_INTERFACE:${include_dir}>
            $<INSTALL_INTERFACE:${CMAKE_INSTALL_INCLUDEDIR}>
    )
endmacro()
macro(add_shared_module name include_dir src_dir)
    file(GLOB_RECURSE src_files CONFIGURE_DEPENDS "${src_dir}/*.cpp" "${src_dir}/*.c" "${src_dir}/*.cu")
    add_library(${name} SHARED ${src_files})
    set_target_properties(${name} PROPERTIES MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>DLL")

    string(TOUPPER ${name} name_upper)
    set(export_subdir "${PROJECT_NAME}/${name}")
    set(export_file_name "${export_subdir}/${name}Export.h")
    generate_export_header(${name}
        EXPORT_MACRO_NAME ${name_upper}_EXPORTS
        EXPORT_FILE_NAME ${export_file_name}
    )
    install(FILES ${CMAKE_CURRENT_BINARY_DIR}/${export_file_name}
            DESTINATION ${CMAKE_INSTALL_INCLUDEDIR}/${export_subdir})
    target_include_directories(${name}
        PUBLIC
            $<BUILD_INTERFACE:${include_dir}>
            $<INSTALL_INTERFACE:${CMAKE_INSTALL_INCLUDEDIR}>
            $<BUILD_INTERFACE:${CMAKE_CURRENT_BINARY_DIR}>
        PRIVATE
            ${src_dir}
    )
    target_compile_definitions(${name} PRIVATE ${name}_EXPORTS)
    if(MSVC)
        install(FILES $<TARGET_PDB_FILE:${name}>
                DESTINATION ${CMAKE_INSTALL_BINDIR}
                CONFIGURATIONS Debug RelWithDebInfo
                OPTIONAL)
    endif()
endmacro()
macro(add_static_md_module name include_dir src_dir)
    file(GLOB_RECURSE src_files CONFIGURE_DEPENDS "${src_dir}/*.cpp" "${src_dir}/*.c" "${src_dir}/*.cu")
    add_library(${name}Static STATIC ${src_files})
    set_target_properties(${name}Static PROPERTIES MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>DLL")
	set_target_properties(${name}Static PROPERTIES POSITION_INDEPENDENT_CODE ON)
    string(TOUPPER ${name} name_upper)

    target_include_directories(${name}Static
        PUBLIC
            $<BUILD_INTERFACE:${include_dir}>
            $<INSTALL_INTERFACE:${CMAKE_INSTALL_INCLUDEDIR}>
            $<BUILD_INTERFACE:${CMAKE_CURRENT_BINARY_DIR}>
        PRIVATE
            ${src_dir}
    )
    target_compile_definitions(${name}Static PUBLIC ${name}_STATIC ${name_upper}_EXPORTS= )
    target_compile_definitions(${name}Static PUBLIC ${name}_STATIC)
endmacro()
macro(add_static_module name include_dir src_dir)
    file(GLOB_RECURSE src_files CONFIGURE_DEPENDS "${src_dir}/*.cpp" "${src_dir}/*.c" "${src_dir}/*.cu")
    add_library(${name}Static STATIC ${src_files})
    set_target_properties(${name}Static PROPERTIES MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
	set_target_properties(${name}Static PROPERTIES POSITION_INDEPENDENT_CODE ON)
    string(TOUPPER ${name} name_upper)
    
    target_include_directories(${name}Static
        PUBLIC
            $<BUILD_INTERFACE:${include_dir}>
            $<INSTALL_INTERFACE:${CMAKE_INSTALL_INCLUDEDIR}>
            $<BUILD_INTERFACE:${CMAKE_CURRENT_BINARY_DIR}>
        PRIVATE
            ${src_dir}
    )

    target_compile_definitions(${name}Static PUBLIC ${name}_STATIC ${name_upper}_EXPORTS= )
    target_compile_definitions(${name}Static PUBLIC ${name}_STATIC)
endmacro()
macro(add_application name include_dir src_dir)
    file(GLOB_RECURSE src_files CONFIGURE_DEPENDS "${src_dir}/*.cpp" "${src_dir}/*.c" "${src_dir}/*.cu")
    add_executable(${name} ${src_files})
    set(use_static_crt OFF)
    string(TOUPPER "${ARGV3}" use_static)
    if("${use_static}" STREQUAL "STATIC")
        set(use_static_crt ON)
    endif()
    message(status "name: ${name}, use_static_crt:${use_static_crt}")
    if(use_static_crt)
        set_target_properties(${name} PROPERTIES MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
    else()
        set_target_properties(${name} PROPERTIES MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>DLL")
    endif()
    target_include_directories(${name}
        PRIVATE
            ${include_dir}
            ${src_dir}
    )
	set_target_properties(${name} PROPERTIES VS_DEBUGGER_WORKING_DIRECTORY "${CMAKE_SOURCE_DIR}/bin/$<CONFIG>")
endmacro()
macro(copy_dll_file name)
    if(WIN32)
        add_custom_command(TARGET ${name} POST_BUILD
		    COMMAND ${CMAKE_COMMAND} -E echo "Copying runtime dependencies..."
            COMMAND ${CMAKE_COMMAND} -E copy_if_different
                $<TARGET_RUNTIME_DLLS:${name}>
                $<TARGET_FILE_DIR:${name}>
		    COMMAND_EXPAND_LISTS
            COMMENT "Copying ${name} DLLs to output directory"
        )
    endif()
endmacro()
macro(copy_zlib_dll_file name include_dir)
    if(WIN32)
	    set(ZLIB_DLL_DEBUG "${include_dir}/../debug/bin/zlibd1.dll")
	    set(ZLIB_DLL_RELEASE "${include_dir}/../bin/zlib1.dll")
	    message("ZLIB_DLL_DEBUG:${ZLIB_DLL_DEBUG}")
	    message("ZLIB_DLL_RELEASE:${ZLIB_DLL_RELEASE}")
	    add_custom_command(TARGET ${name} POST_BUILD
            COMMAND ${CMAKE_COMMAND} -E echo "Copying ZLIB for $<CONFIG>..."
            COMMAND ${CMAKE_COMMAND} -E copy_if_different
                $<TARGET_RUNTIME_DLLS:${name}>
                "$<$<CONFIG:Debug>:${ZLIB_DLL_RELEASE}>"
                "$<$<CONFIG:Release>:${ZLIB_DLL_RELEASE}>"
                $<TARGET_FILE_DIR:${name}>
            COMMAND_EXPAND_LISTS
            COMMENT "Copying ZLIB DLLs to output directory"
        )
    endif()
endmacro()
macro(copy_config_file name config_file)
    add_custom_command(TARGET ${name} POST_BUILD
        COMMAND ${CMAKE_COMMAND} -E copy_if_different
            ${config_file}
            $<TARGET_FILE_DIR:${name}>
        COMMENT "Copying config file ${config_file} to output directory"
    )
endmacro()
