﻿#pragma once
#include <unordered_set>
#include "MdbStructs.h"
#include "MdbPrimaryKeyComp.h"

namespace mdb
{
	class TradingDayTable;
	class TradingDayPrimaryKey
	{
		using iterator = std::unordered_set<TradingDay*, TradingDayHashForTradingDayPrimaryKey, TradingDayEqualForTradingDayPrimaryKey>::iterator;
		friend class TradingDayTable;
	public:
		TradingDayPrimaryKey(TradingDayTable* table, size_t buckets = 1000);
		TradingDay* Select(const IntType& PK);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(TradingDay* const record);
		void Erase(TradingDay* const record);
		bool CheckInsert(TradingDay* const record);
		bool CheckUpdate(const TradingDay* const oldRecord, const TradingDay* const newRecord);

	private:
		TradingDayTable* m_Table;
		std::unordered_set<TradingDay*, TradingDayHashForTradingDayPrimaryKey, TradingDayEqualForTradingDayPrimaryKey> m_Index;
	};
	class ExchangeTable;
	class ExchangePrimaryKey
	{
		using iterator = std::unordered_set<Exchange*, ExchangeHashForExchangePrimaryKey, ExchangeEqualForExchangePrimaryKey>::iterator;
		friend class ExchangeTable;
	public:
		ExchangePrimaryKey(ExchangeTable* table, size_t buckets = 1000);
		Exchange* Select(const ExchangeIDType& ExchangeID);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(Exchange* const record);
		void Erase(Exchange* const record);
		bool CheckInsert(Exchange* const record);
		bool CheckUpdate(const Exchange* const oldRecord, const Exchange* const newRecord);

	private:
		ExchangeTable* m_Table;
		std::unordered_set<Exchange*, ExchangeHashForExchangePrimaryKey, ExchangeEqualForExchangePrimaryKey> m_Index;
	};
	class ProductTable;
	class ProductPrimaryKey
	{
		using iterator = std::unordered_set<Product*, ProductHashForProductPrimaryKey, ProductEqualForProductPrimaryKey>::iterator;
		friend class ProductTable;
	public:
		ProductPrimaryKey(ProductTable* table, size_t buckets = 1000);
		Product* Select(const ExchangeIDType& ExchangeID, const ProductIDType& ProductID);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(Product* const record);
		void Erase(Product* const record);
		bool CheckInsert(Product* const record);
		bool CheckUpdate(const Product* const oldRecord, const Product* const newRecord);

	private:
		ProductTable* m_Table;
		std::unordered_set<Product*, ProductHashForProductPrimaryKey, ProductEqualForProductPrimaryKey> m_Index;
	};
	class HotInstrumentTable;
	class HotInstrumentPrimaryKey
	{
		using iterator = std::unordered_set<HotInstrument*, HotInstrumentHashForHotInstrumentPrimaryKey, HotInstrumentEqualForHotInstrumentPrimaryKey>::iterator;
		friend class HotInstrumentTable;
	public:
		HotInstrumentPrimaryKey(HotInstrumentTable* table, size_t buckets = 1000);
		HotInstrument* Select(const DateType& TradingDay, const ExchangeIDType& ExchangeID, const ProductIDType& ProductID, const IntType& Rank);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(HotInstrument* const record);
		void Erase(HotInstrument* const record);
		bool CheckInsert(HotInstrument* const record);
		bool CheckUpdate(const HotInstrument* const oldRecord, const HotInstrument* const newRecord);

	private:
		HotInstrumentTable* m_Table;
		std::unordered_set<HotInstrument*, HotInstrumentHashForHotInstrumentPrimaryKey, HotInstrumentEqualForHotInstrumentPrimaryKey> m_Index;
	};
	class InstrumentTable;
	class InstrumentPrimaryKey
	{
		using iterator = std::unordered_set<Instrument*, InstrumentHashForInstrumentPrimaryKey, InstrumentEqualForInstrumentPrimaryKey>::iterator;
		friend class InstrumentTable;
	public:
		InstrumentPrimaryKey(InstrumentTable* table, size_t buckets = 1000);
		Instrument* Select(const ExchangeIDType& ExchangeID, const InstrumentIDType& InstrumentID);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(Instrument* const record);
		void Erase(Instrument* const record);
		bool CheckInsert(Instrument* const record);
		bool CheckUpdate(const Instrument* const oldRecord, const Instrument* const newRecord);

	private:
		InstrumentTable* m_Table;
		std::unordered_set<Instrument*, InstrumentHashForInstrumentPrimaryKey, InstrumentEqualForInstrumentPrimaryKey> m_Index;
	};
	class DepthMarketDataTable;
	class DepthMarketDataPrimaryKey
	{
		using iterator = std::unordered_set<DepthMarketData*, DepthMarketDataHashForDepthMarketDataPrimaryKey, DepthMarketDataEqualForDepthMarketDataPrimaryKey>::iterator;
		friend class DepthMarketDataTable;
	public:
		DepthMarketDataPrimaryKey(DepthMarketDataTable* table, size_t buckets = 1000);
		DepthMarketData* Select(const DateType& TradingDay, const ExchangeIDType& ExchangeID, const InstrumentIDType& InstrumentID);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(DepthMarketData* const record);
		void Erase(DepthMarketData* const record);
		bool CheckInsert(DepthMarketData* const record);
		bool CheckUpdate(const DepthMarketData* const oldRecord, const DepthMarketData* const newRecord);

	private:
		DepthMarketDataTable* m_Table;
		std::unordered_set<DepthMarketData*, DepthMarketDataHashForDepthMarketDataPrimaryKey, DepthMarketDataEqualForDepthMarketDataPrimaryKey> m_Index;
	};
	class BarMarketDataTable;
	class BarMarketDataPrimaryKey
	{
		using iterator = std::unordered_set<BarMarketData*, BarMarketDataHashForBarMarketDataPrimaryKey, BarMarketDataEqualForBarMarketDataPrimaryKey>::iterator;
		friend class BarMarketDataTable;
	public:
		BarMarketDataPrimaryKey(BarMarketDataTable* table, size_t buckets = 1000);
		BarMarketData* Select(const DateType& TradingDay, const ExchangeIDType& ExchangeID, const InstrumentIDType& InstrumentID, const BarPrecesType& BarPreces, const IntType& BarPeriod, const Int64Type& BarTime);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(BarMarketData* const record);
		void Erase(BarMarketData* const record);
		bool CheckInsert(BarMarketData* const record);
		bool CheckUpdate(const BarMarketData* const oldRecord, const BarMarketData* const newRecord);

	private:
		BarMarketDataTable* m_Table;
		std::unordered_set<BarMarketData*, BarMarketDataHashForBarMarketDataPrimaryKey, BarMarketDataEqualForBarMarketDataPrimaryKey> m_Index;
	};
	class MdSubscribeTable;
	class MdSubscribePrimaryKey
	{
		using iterator = std::unordered_set<MdSubscribe*, MdSubscribeHashForMdSubscribePrimaryKey, MdSubscribeEqualForMdSubscribePrimaryKey>::iterator;
		friend class MdSubscribeTable;
	public:
		MdSubscribePrimaryKey(MdSubscribeTable* table, size_t buckets = 1000);
		MdSubscribe* Select(const ExchangeIDType& ExchangeID, const InstrumentIDType& InstrumentID, const DateType& StartTradingDay);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(MdSubscribe* const record);
		void Erase(MdSubscribe* const record);
		bool CheckInsert(MdSubscribe* const record);
		bool CheckUpdate(const MdSubscribe* const oldRecord, const MdSubscribe* const newRecord);

	private:
		MdSubscribeTable* m_Table;
		std::unordered_set<MdSubscribe*, MdSubscribeHashForMdSubscribePrimaryKey, MdSubscribeEqualForMdSubscribePrimaryKey> m_Index;
	};
	class MdUserTable;
	class MdUserPrimaryKey
	{
		using iterator = std::unordered_set<MdUser*, MdUserHashForMdUserPrimaryKey, MdUserEqualForMdUserPrimaryKey>::iterator;
		friend class MdUserTable;
	public:
		MdUserPrimaryKey(MdUserTable* table, size_t buckets = 1000);
		MdUser* Select(const UserIDType& MdUserID);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(MdUser* const record);
		void Erase(MdUser* const record);
		bool CheckInsert(MdUser* const record);
		bool CheckUpdate(const MdUser* const oldRecord, const MdUser* const newRecord);

	private:
		MdUserTable* m_Table;
		std::unordered_set<MdUser*, MdUserHashForMdUserPrimaryKey, MdUserEqualForMdUserPrimaryKey> m_Index;
	};
	class MdUserLoginSessionTable;
	class MdUserLoginSessionPrimaryKey
	{
		using iterator = std::unordered_set<MdUserLoginSession*, MdUserLoginSessionHashForMdUserLoginSessionPrimaryKey, MdUserLoginSessionEqualForMdUserLoginSessionPrimaryKey>::iterator;
		friend class MdUserLoginSessionTable;
	public:
		MdUserLoginSessionPrimaryKey(MdUserLoginSessionTable* table, size_t buckets = 1000);
		MdUserLoginSession* Select(const SessionIDType& SessionID);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(MdUserLoginSession* const record);
		void Erase(MdUserLoginSession* const record);
		bool CheckInsert(MdUserLoginSession* const record);
		bool CheckUpdate(const MdUserLoginSession* const oldRecord, const MdUserLoginSession* const newRecord);

	private:
		MdUserLoginSessionTable* m_Table;
		std::unordered_set<MdUserLoginSession*, MdUserLoginSessionHashForMdUserLoginSessionPrimaryKey, MdUserLoginSessionEqualForMdUserLoginSessionPrimaryKey> m_Index;
	};
	class PrimaryAccountTable;
	class PrimaryAccountPrimaryKey
	{
		using iterator = std::unordered_set<PrimaryAccount*, PrimaryAccountHashForPrimaryAccountPrimaryKey, PrimaryAccountEqualForPrimaryAccountPrimaryKey>::iterator;
		friend class PrimaryAccountTable;
	public:
		PrimaryAccountPrimaryKey(PrimaryAccountTable* table, size_t buckets = 1000);
		PrimaryAccount* Select(const AccountIDType& PrimaryAccountID);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(PrimaryAccount* const record);
		void Erase(PrimaryAccount* const record);
		bool CheckInsert(PrimaryAccount* const record);
		bool CheckUpdate(const PrimaryAccount* const oldRecord, const PrimaryAccount* const newRecord);

	private:
		PrimaryAccountTable* m_Table;
		std::unordered_set<PrimaryAccount*, PrimaryAccountHashForPrimaryAccountPrimaryKey, PrimaryAccountEqualForPrimaryAccountPrimaryKey> m_Index;
	};
	class AccountTable;
	class AccountPrimaryKey
	{
		using iterator = std::unordered_set<Account*, AccountHashForAccountPrimaryKey, AccountEqualForAccountPrimaryKey>::iterator;
		friend class AccountTable;
	public:
		AccountPrimaryKey(AccountTable* table, size_t buckets = 1000);
		Account* Select(const AccountIDType& AccountID);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(Account* const record);
		void Erase(Account* const record);
		bool CheckInsert(Account* const record);
		bool CheckUpdate(const Account* const oldRecord, const Account* const newRecord);

	private:
		AccountTable* m_Table;
		std::unordered_set<Account*, AccountHashForAccountPrimaryKey, AccountEqualForAccountPrimaryKey> m_Index;
	};
	class CapitalTable;
	class CapitalPrimaryKey
	{
		using iterator = std::unordered_set<Capital*, CapitalHashForCapitalPrimaryKey, CapitalEqualForCapitalPrimaryKey>::iterator;
		friend class CapitalTable;
	public:
		CapitalPrimaryKey(CapitalTable* table, size_t buckets = 1000);
		Capital* Select(const DateType& TradingDay, const AccountIDType& AccountID);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(Capital* const record);
		void Erase(Capital* const record);
		bool CheckInsert(Capital* const record);
		bool CheckUpdate(const Capital* const oldRecord, const Capital* const newRecord);

	private:
		CapitalTable* m_Table;
		std::unordered_set<Capital*, CapitalHashForCapitalPrimaryKey, CapitalEqualForCapitalPrimaryKey> m_Index;
	};
	class PositionTable;
	class PositionPrimaryKey
	{
		using iterator = std::unordered_set<Position*, PositionHashForPositionPrimaryKey, PositionEqualForPositionPrimaryKey>::iterator;
		friend class PositionTable;
	public:
		PositionPrimaryKey(PositionTable* table, size_t buckets = 1000);
		Position* Select(const DateType& TradingDay, const AccountIDType& AccountID, const ExchangeIDType& ExchangeID, const InstrumentIDType& InstrumentID, const PosiDirectionType& PosiDirection);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(Position* const record);
		void Erase(Position* const record);
		bool CheckInsert(Position* const record);
		bool CheckUpdate(const Position* const oldRecord, const Position* const newRecord);

	private:
		PositionTable* m_Table;
		std::unordered_set<Position*, PositionHashForPositionPrimaryKey, PositionEqualForPositionPrimaryKey> m_Index;
	};
	class PositionDetailTable;
	class PositionDetailPrimaryKey
	{
		using iterator = std::unordered_set<PositionDetail*, PositionDetailHashForPositionDetailPrimaryKey, PositionDetailEqualForPositionDetailPrimaryKey>::iterator;
		friend class PositionDetailTable;
	public:
		PositionDetailPrimaryKey(PositionDetailTable* table, size_t buckets = 1000);
		PositionDetail* Select(const DateType& TradingDay, const AccountIDType& AccountID, const ExchangeIDType& ExchangeID, const InstrumentIDType& InstrumentID, const PosiDirectionType& PosiDirection, const DateType& OpenDate, const TradeIDType& TradeID);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(PositionDetail* const record);
		void Erase(PositionDetail* const record);
		bool CheckInsert(PositionDetail* const record);
		bool CheckUpdate(const PositionDetail* const oldRecord, const PositionDetail* const newRecord);

	private:
		PositionDetailTable* m_Table;
		std::unordered_set<PositionDetail*, PositionDetailHashForPositionDetailPrimaryKey, PositionDetailEqualForPositionDetailPrimaryKey> m_Index;
	};
	class OrderTable;
	class OrderPrimaryKey
	{
		using iterator = std::unordered_set<Order*, OrderHashForOrderPrimaryKey, OrderEqualForOrderPrimaryKey>::iterator;
		friend class OrderTable;
	public:
		OrderPrimaryKey(OrderTable* table, size_t buckets = 1000);
		Order* Select(const DateType& TradingDay, const AccountIDType& AccountID, const ExchangeIDType& ExchangeID, const InstrumentIDType& InstrumentID, const OrderIDType& OrderID);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(Order* const record);
		void Erase(Order* const record);
		bool CheckInsert(Order* const record);
		bool CheckUpdate(const Order* const oldRecord, const Order* const newRecord);

	private:
		OrderTable* m_Table;
		std::unordered_set<Order*, OrderHashForOrderPrimaryKey, OrderEqualForOrderPrimaryKey> m_Index;
	};
	class OrderUniqueKeyClientOrderID
	{
		friend class OrderTable;
	public:
		OrderUniqueKeyClientOrderID(OrderTable* table, size_t buckets = 1000);
		Order* Select(const DateType& TradingDay, const AccountIDType& AccountID, const ExchangeIDType& ExchangeID, const InstrumentIDType& InstrumentID, const SessionIDType& SessionID, const ClientOrderIDType& ClientOrderID);
		
	protected:
		bool Insert(Order* const record);
		void Erase(Order* const record);
		bool CheckInsert(Order* const record);
		bool CheckUpdate(const Order* const oldRecord, const Order* const newRecord);

	private:
		OrderTable* m_Table;
		std::unordered_set<Order*, OrderHashForClientOrderIDUniqueKey, OrderEqualForClientOrderIDUniqueKey> m_Index;
	};
	
	class TradeTable;
	class TradePrimaryKey
	{
		using iterator = std::unordered_set<Trade*, TradeHashForTradePrimaryKey, TradeEqualForTradePrimaryKey>::iterator;
		friend class TradeTable;
	public:
		TradePrimaryKey(TradeTable* table, size_t buckets = 1000);
		Trade* Select(const DateType& TradingDay, const ExchangeIDType& ExchangeID, const TradeIDType& TradeID, const DirectionType& Direction);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(Trade* const record);
		void Erase(Trade* const record);
		bool CheckInsert(Trade* const record);
		bool CheckUpdate(const Trade* const oldRecord, const Trade* const newRecord);

	private:
		TradeTable* m_Table;
		std::unordered_set<Trade*, TradeHashForTradePrimaryKey, TradeEqualForTradePrimaryKey> m_Index;
	};
	class AccountLoginSessionTable;
	class AccountLoginSessionPrimaryKey
	{
		using iterator = std::unordered_set<AccountLoginSession*, AccountLoginSessionHashForAccountLoginSessionPrimaryKey, AccountLoginSessionEqualForAccountLoginSessionPrimaryKey>::iterator;
		friend class AccountLoginSessionTable;
	public:
		AccountLoginSessionPrimaryKey(AccountLoginSessionTable* table, size_t buckets = 1000);
		AccountLoginSession* Select(const SessionIDType& SessionID);
		std::pair<iterator, iterator> SelectAll();
		
	protected:
		bool Insert(AccountLoginSession* const record);
		void Erase(AccountLoginSession* const record);
		bool CheckInsert(AccountLoginSession* const record);
		bool CheckUpdate(const AccountLoginSession* const oldRecord, const AccountLoginSession* const newRecord);

	private:
		AccountLoginSessionTable* m_Table;
		std::unordered_set<AccountLoginSession*, AccountLoginSessionHashForAccountLoginSessionPrimaryKey, AccountLoginSessionEqualForAccountLoginSessionPrimaryKey> m_Index;
	};
}
